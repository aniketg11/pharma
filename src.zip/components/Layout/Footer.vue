<template>
  <div class="footer">
    <b-navbar >
      <b-navbar-nav>
        <b-nav-item href="#" >
            <b-icon icon="linkedin" style="color: #0e76a8;" aria-hidden="true"></b-icon>
        </b-nav-item>
        <b-nav-item href="#" >
            <b-icon style="color: #4267B2;" icon="facebook" aria-hidden="true"></b-icon>
        </b-nav-item>
        <b-nav-item href="#" >
            <b-icon icon="twitter" style="color: #00acee;" aria-hidden="true"></b-icon>
        </b-nav-item>
      </b-navbar-nav>
    </b-navbar>
    <div>
      Copyright &#169; 2021 Besuto PharmaPack Solution PVT LTD All Rights Reserved
    </div>
  </div>
</template>

<script>
// @ is an alias to /src

export default {
  name: "Footer",
  components: {},
};
</script>
