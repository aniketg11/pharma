<template>
  <div class="contentDiv">
    <b-container>
      <b-row>
        <b-col class="m-auto w-50" lg="8" md="8" sm="8">
          <h3 class="colorBlue">Abuot Besuto PharmaPack Solution PVT LTD</h3>
        </b-col>
        <b-col lg="4" md="4" sm="4">
          <img
            class="w-100"
            src="../assets/machine.png"
            fluid
            alt="Fluid image"
          />
        </b-col>
      </b-row>
      <p style="text-align: initial;">
        Besuto pharmapack Solution Pvt Ltd India offering a complete turnkey
        packaging solutions for pharmaceutical industries. With experience
        spanning over 15 Plus Years, in Parma packaging area, master in
        providing Blister Packing Machines, Cartoning Machines, Wrapping
        Machines, Change parts/Format parts for Blister and Cartoning Machines
        with after sales support & servicing. As per our quality policy, with
        our experience & innovative thoughts, Right from designing to
        procurement of right quality materials to inspection, assembly and final
        testing is done in-house.As per our service policy, with a dedicated
        team for after sales support, including qualified and experienced
        support team, helps to meet diverse needs and challenges of our clients
        anywhere anytime across country & world.
      </p>
      <p style="text-align: initial;">
        As per our customer first policy, we understand need of client &
        recognize the importance of on time, cost effective quality solution,
        and focus on ensuring best optimal solution for all format Change
        parts/Format parts  needs in Blister packing and Cartoning machines.As a
        fast growing Engineering Company, we aspire to transform aggressively
        and create a niche for ourselves in the global market in manufacturing
        of format parts and blister packing machines.We Exceed Customer
        Expectation by Delivering The Best Product With Quality Service-by
        adopting & devising Advanced Manufacturing Techniques to Enhance
        Quality. We want to be a top most organisation in Cartoning Machines,
        Wrapping Machines, Change parts/Format parts for Blister and Cartoning
        Machines with after sales support & servicing
      </p>
      <b-row>
        <b-col lg="4" sm="12">
          <div class="circle m-auto w-50">
            <h4 class="display-6 pt-5">Vision</h4>
            <p class="pt-2">
              <small>
                To be global leader in manufacturing of pharma equipments,
                through constant growth & innoviation.
              </small>
            </p>
            <img class="w-25" src="../assets/eye.svg" fluid alt="Fluid image" />
          </div>
        </b-col>
        <b-col lg="4" sm="12">
          <div class="circle m-auto w-50">
            <h4 class="display-6 pt-5">Mission</h4>
            <p class="pt-2">
              <small>
                To delivery the best quality machinery powered by innovation to
                our esteemed clientele with the help.
              </small>
            </p>
            <img
              class="w-25"
              src="../assets/mission.svg"
              fluid
              alt="Fluid image"
            />
          </div>
        </b-col>
        <b-col lg="4" sm="12">
          <div class="circle m-auto w-50">
            <h4 class="display-6 pt-5">Quality</h4>
            <p class="pt-2">
              <small>
                To constantly enhance the quality and longevity of our product
                by following best manufacturing practices.
              </small>
            </p>
            <img
              class="w-25"
              src="../assets/medal.svg"
              fluid
              alt="Fluid image"
            />
          </div>
        </b-col>
      </b-row>
			<img
					class="aboutUsBaner d-block m-auto  w-80"
					height="25%"
					src="../assets/prod_line.png"
					fluid
					alt="Fluid image"
				/>
    </b-container>
  </div>
</template>

<script>
// @ is an alias to /src

export default {
  name: "AboutUs",
  components: {},
};
</script>
